# Ramiro el Vampiro y el Misterio del Papiro

This game was left abandoned and unfinished due to lack of interest, more interesting things, Ninjajar!, the new MK1, and a Pendrive crash.

I managed to find and rescue some material and recreated as if it was made in 2013.

Enjoy
