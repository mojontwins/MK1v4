# Los enemigos

Si alguien (ja ja ja ja ) va a usar la v4 de MTE MK1 para algo, debe asegurarse de que los archivos .ene se guardan con el formato *legacy* de 2 bytes por hotspot. 

El ponedor detectará automáticamente este setting en archivos .ene originales, pero si se crea un nuevo hay que especificarlo. 

El modo de compatibilidad puede comprobarse examinando la parte superior de la ventana, sobre la rejilla de edición. Si aparece `2b`, el .ene estará en formato *legacy*. Si aparece `3b`, en el formato actual. Para cambiar de uno al otro basta con pulsar la tecla `L`

Si no quieres usar la linea de comandos simplemente arrastra `enems.ene` sobre `ponedor.bat`.

Para exportar `enems.h` como en los viejos tiempos, pulsa sobre el botón `H` situado en la barra de botones de la parte inferior.
