// Custom player cells array

// In this case, the spriteset is:
// 1  2  3  4  5  6  7  8  9  10
// R1 R2 R3 RJ RH L1 L2 L3 LJ LH

unsigned char *player_cells [] = {
	sprite_1_a, sprite_2_a, sprite_3_a, sprite_4_a, extra_sprite_22_a,
	sprite_5_a, sprite_6_a, sprite_7_a, sprite_8_a, extra_sprite_23_a
};
