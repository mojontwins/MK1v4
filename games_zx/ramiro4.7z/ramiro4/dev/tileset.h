// MTE MK1 v4.8
// Copyleft 2010-2013, 2020-2021 by The Mojon Twins

extern unsigned char tileset [0];
#asm
	._tileset
		BINARY "tileset.bin"
#endasm
