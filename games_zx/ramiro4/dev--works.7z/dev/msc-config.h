// msc.h
// Generado por Mojon Script Compiler de MTE MK1 v4
// Copyleft 2011 The Mojon Twins
 
unsigned char script_result = 0;
unsigned char script_something_done = 0;
 
#define DEACTIVATE_FIRE_ZONE
