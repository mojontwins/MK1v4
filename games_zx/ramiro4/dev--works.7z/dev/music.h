// MTE MK1 v4.8
// Copyleft 2010-2013, 2020-2021 by The Mojon Twins

// Substitute with beepola stuff or whatever you like.

#asm
.musicstart
	ret
#endasm
