// MTE MK1 v4.7
// Copyleft 2010, 2011 by The Mojon Twins

// Substitute with beepola stuff or whatever you like.

#asm
.musicstart
	ret
#endasm
