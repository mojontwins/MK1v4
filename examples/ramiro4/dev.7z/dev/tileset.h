// MTE MK1 v4.7
// Copyleft 2010, 2011 by The Mojon Twins

extern unsigned char tileset [0];
#asm
	._tileset
		BINARY "tileset.bin"
#endasm
