// Data created with Img2CPC
//(c) 2007 CEZ Team

extern unsigned char spr_0_DATA[];
extern unsigned char spr_1_DATA[];
extern unsigned char spr_2_DATA[];
extern unsigned char spr_3_DATA[];
extern unsigned char spr_4_DATA[];
extern unsigned char spr_5_DATA[];
extern unsigned char spr_6_DATA[];
extern unsigned char spr_7_DATA[];
extern unsigned char spr_8_DATA[];
extern unsigned char spr_9_DATA[];
extern unsigned char spr_10_DATA[];
extern unsigned char spr_11_DATA[];
extern unsigned char spr_12_DATA[];
extern unsigned char spr_13_DATA[];
extern unsigned char spr_14_DATA[];
extern unsigned char spr_15_DATA[];
extern unsigned char spr_16_DATA[];
extern unsigned char spr_17_DATA[];
extern unsigned char spr_18_DATA[];
extern unsigned char spr_19_DATA[];
extern unsigned char spr_20_DATA[];
extern unsigned char spr_21_DATA[];
extern unsigned char spr_22_DATA[];
extern unsigned char spr_23_DATA[];
extern unsigned char spr_24_DATA[];
extern unsigned char spr_25_DATA[];
extern unsigned char spr_26_DATA[];
extern unsigned char spr_27_DATA[];
extern unsigned char spr_28_DATA[];
extern unsigned char spr_29_DATA[];
extern unsigned char spr_30_DATA[];
extern unsigned char spr_31_DATA[];
unsigned char *tiles [] = {
	spr_0_DATA, spr_1_DATA, spr_2_DATA, spr_3_DATA, spr_4_DATA, spr_5_DATA, spr_6_DATA, spr_7_DATA, spr_8_DATA, spr_9_DATA, spr_10_DATA, spr_11_DATA, spr_12_DATA, spr_13_DATA, spr_14_DATA, spr_15_DATA, spr_16_DATA, spr_17_DATA, spr_18_DATA, spr_19_DATA, spr_20_DATA, spr_21_DATA, spr_22_DATA, spr_23_DATA, spr_24_DATA, spr_25_DATA, spr_26_DATA, spr_27_DATA, spr_28_DATA, spr_29_DATA, spr_30_DATA, spr_31_DATA
		};
#asm
; Data from file sprites.png (256x32)... Mode 1.
._spr_0
defb $4, $10
._spr_0_DATA
defb $0, $0, $0, $0
defb $0, $10, $F0, $0
defb $0, $30, $5A, $80
defb $0, $61, $A5, $80
defb $0, $52, $F0, $80
defb $10, $F0, $BA, $0
defb $30, $FD, $FE, $0
defb $31, $F1, $BA, $0
defb $31, $B4, $F0, $0
defb $31, $B5, $D8, $0
defb $71, $F1, $DA, $0
defb $72, $F0, $F0, $0
defb $72, $E9, $F0, $80
defb $73, $F0, $4B, $80
defb $70, $D2, $87, $80
defb $0, $61, $D2, $80
._spr_1
defb $4, $10
._spr_1_DATA
defb $FF, $FF, $FF, $FF
defb $FF, $EE, $0, $FF
defb $FF, $CC, $0, $77
defb $FF, $88, $0, $77
defb $FF, $88, $0, $77
defb $EE, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $88, $0, $0, $FF
defb $88, $0, $0, $FF
defb $88, $0, $0, $77
defb $88, $0, $0, $77
defb $88, $0, $0, $77
defb $FF, $88, $0, $77
._spr_2
defb $4, $10
._spr_2_DATA
defb $0, $10, $F0, $0
defb $0, $30, $5A, $80
defb $0, $61, $A5, $80
defb $0, $D2, $F0, $80
defb $0, $B4, $BA, $0
defb $10, $F1, $FE, $0
defb $30, $FD, $BA, $0
defb $31, $F0, $F0, $C0
defb $71, $87, $D2, $C8
defb $72, $E5, $12, $C8
defb $72, $ED, $1E, $C0
defb $F2, $FC, $F0, $0
defb $F4, $E1, $D2, $0
defb $F5, $E1, $D2, $80
defb $F6, $CB, $69, $C0
defb $F0, $C3, $3C, $48
._spr_3
defb $4, $10
._spr_3_DATA
defb $FF, $EE, $0, $FF
defb $FF, $CC, $0, $77
defb $FF, $88, $0, $77
defb $FF, $0, $0, $77
defb $FF, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $CC, $0, $0, $33
defb $88, $0, $0, $33
defb $88, $0, $0, $33
defb $88, $0, $0, $33
defb $0, $0, $0, $FF
defb $0, $0, $0, $FF
defb $0, $0, $0, $77
defb $0, $0, $0, $33
defb $0, $0, $0, $33
._spr_4
defb $4, $10
._spr_4_DATA
defb $0, $0, $0, $0
defb $0, $10, $F0, $0
defb $0, $30, $5A, $80
defb $0, $61, $A5, $80
defb $0, $52, $F0, $80
defb $10, $F0, $BA, $0
defb $30, $FD, $FE, $0
defb $71, $F1, $BA, $E0
defb $72, $F0, $F0, $EC
defb $72, $ED, $12, $EC
defb $72, $ED, $1E, $E0
defb $72, $F0, $F0, $0
defb $72, $E9, $78, $0
defb $73, $C3, $D2, $C0
defb $70, $C3, $4B, $48
defb $0, $61, $69, $C0
._spr_5
defb $4, $10
._spr_5_DATA
defb $FF, $FF, $FF, $FF
defb $FF, $EE, $0, $FF
defb $FF, $CC, $0, $77
defb $FF, $88, $0, $77
defb $FF, $88, $0, $77
defb $EE, $0, $0, $FF
defb $CC, $0, $0, $FF
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $FF
defb $88, $0, $0, $FF
defb $88, $0, $0, $33
defb $88, $0, $0, $33
defb $FF, $88, $0, $33
._spr_6
defb $4, $10
._spr_6_DATA
defb $0, $10, $F0, $0
defb $0, $30, $5A, $80
defb $0, $61, $B4, $80
defb $0, $52, $F0, $80
defb $10, $F0, $BA, $E0
defb $10, $FD, $FE, $EC
defb $10, $FD, $BA, $EC
defb $30, $F0, $F0, $E0
defb $71, $87, $E1, $48
defb $72, $E1, $12, $E0
defb $F2, $E1, $1E, $A4
defb $F4, $F0, $F0, $2C
defb $F3, $F2, $96, $2C
defb $71, $FC, $F0, $E0
defb $30, $E0, $0, $0
defb $0, $0, $0, $0
._spr_7
defb $4, $10
._spr_7_DATA
defb $FF, $EE, $0, $FF
defb $FF, $CC, $0, $77
defb $FF, $88, $0, $77
defb $FF, $88, $0, $77
defb $EE, $0, $0, $11
defb $EE, $0, $0, $11
defb $EE, $0, $0, $11
defb $CC, $0, $0, $11
defb $88, $0, $0, $33
defb $88, $0, $0, $11
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $88, $0, $0, $11
defb $CC, $11, $FF, $FF
defb $FF, $FF, $FF, $FF
._spr_8
defb $4, $10
._spr_8_DATA
defb $0, $0, $0, $0
defb $0, $F0, $80, $0
defb $10, $A5, $C0, $0
defb $10, $5A, $68, $0
defb $10, $F0, $A4, $0
defb $0, $D5, $F0, $80
defb $0, $F7, $FB, $C0
defb $0, $D5, $F8, $C8
defb $0, $F0, $D2, $C8
defb $0, $B1, $DA, $C8
defb $0, $B5, $F8, $E8
defb $0, $F0, $F0, $E4
defb $10, $F0, $79, $E4
defb $10, $2D, $F0, $EC
defb $10, $1E, $B4, $E0
defb $10, $B4, $68, $0
._spr_9
defb $4, $10
._spr_9_DATA
defb $FF, $FF, $FF, $FF
defb $FF, $0, $77, $FF
defb $EE, $0, $33, $FF
defb $EE, $0, $11, $FF
defb $EE, $0, $11, $FF
defb $FF, $0, $0, $77
defb $FF, $0, $0, $33
defb $FF, $0, $0, $33
defb $FF, $0, $0, $33
defb $FF, $0, $0, $33
defb $FF, $0, $0, $11
defb $FF, $0, $0, $11
defb $EE, $0, $0, $11
defb $EE, $0, $0, $11
defb $EE, $0, $0, $11
defb $EE, $0, $11, $FF
._spr_10
defb $4, $10
._spr_10_DATA
defb $0, $F0, $80, $0
defb $10, $A5, $C0, $0
defb $10, $5A, $68, $0
defb $10, $F0, $B4, $0
defb $0, $D5, $D2, $0
defb $0, $F7, $F8, $80
defb $0, $D5, $FB, $C0
defb $30, $F0, $F0, $C8
defb $31, $F0, $1E, $E8
defb $31, $84, $78, $E4
defb $30, $87, $7B, $E4
defb $0, $F0, $F3, $F4
defb $0, $B4, $78, $F2
defb $10, $B4, $78, $FA
defb $30, $69, $3D, $F6
defb $21, $C3, $3C, $F0
._spr_11
defb $4, $10
._spr_11_DATA
defb $FF, $0, $77, $FF
defb $EE, $0, $33, $FF
defb $EE, $0, $11, $FF
defb $EE, $0, $0, $FF
defb $FF, $0, $0, $FF
defb $FF, $0, $0, $77
defb $FF, $0, $0, $33
defb $CC, $0, $0, $33
defb $CC, $0, $0, $11
defb $CC, $0, $0, $11
defb $CC, $0, $0, $11
defb $FF, $0, $0, $0
defb $FF, $0, $0, $0
defb $EE, $0, $0, $0
defb $CC, $0, $0, $0
defb $CC, $0, $0, $0
._spr_12
defb $4, $10
._spr_12_DATA
defb $0, $0, $0, $0
defb $0, $F0, $80, $0
defb $10, $A5, $C0, $0
defb $10, $5A, $68, $0
defb $10, $F0, $A4, $0
defb $0, $D5, $F0, $80
defb $0, $F7, $FB, $C0
defb $70, $D5, $F8, $E8
defb $73, $F0, $F0, $E4
defb $73, $84, $7B, $E4
defb $70, $87, $7B, $E4
defb $0, $F0, $F0, $E4
defb $0, $E1, $79, $E4
defb $30, $B4, $3C, $EC
defb $21, $2D, $3C, $E0
defb $30, $69, $68, $0
._spr_13
defb $4, $10
._spr_13_DATA
defb $FF, $FF, $FF, $FF
defb $FF, $0, $77, $FF
defb $EE, $0, $33, $FF
defb $EE, $0, $11, $FF
defb $EE, $0, $11, $FF
defb $FF, $0, $0, $77
defb $FF, $0, $0, $33
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $FF, $0, $0, $11
defb $FF, $0, $0, $11
defb $CC, $0, $0, $11
defb $CC, $0, $0, $11
defb $CC, $0, $11, $FF
._spr_14
defb $4, $10
._spr_14_DATA
defb $0, $F0, $80, $0
defb $10, $A5, $C0, $0
defb $10, $D2, $68, $0
defb $10, $F0, $A4, $0
defb $70, $D5, $F0, $80
defb $73, $F7, $FB, $80
defb $73, $D5, $FB, $80
defb $70, $F0, $F0, $C0
defb $21, $78, $1E, $E8
defb $70, $84, $78, $E4
defb $52, $87, $78, $F4
defb $43, $F0, $F0, $F2
defb $43, $96, $F4, $FC
defb $70, $F0, $F3, $E8
defb $0, $0, $70, $C0
defb $0, $0, $0, $0
._spr_15
defb $4, $10
._spr_15_DATA
defb $FF, $0, $77, $FF
defb $EE, $0, $33, $FF
defb $EE, $0, $11, $FF
defb $EE, $0, $11, $FF
defb $88, $0, $0, $77
defb $88, $0, $0, $77
defb $88, $0, $0, $77
defb $88, $0, $0, $33
defb $CC, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $11
defb $FF, $FF, $88, $33
defb $FF, $FF, $FF, $FF
._spr_16
defb $4, $10
._spr_16_DATA
defb $0, $F0, $E0, $0
defb $10, $F7, $3C, $0
defb $10, $FD, $D6, $0
defb $10, $FD, $D6, $0
defb $10, $DD, $56, $0
defb $10, $FF, $DE, $0
defb $10, $7F, $DE, $0
defb $0, $D5, $34, $80
defb $30, $F0, $E1, $80
defb $31, $FA, $78, $80
defb $31, $F9, $A4, $0
defb $30, $F0, $E0, $0
defb $0, $31, $A4, $0
defb $0, $31, $E0, $0
defb $0, $F0, $80, $0
defb $0, $E7, $80, $0
._spr_17
defb $4, $10
._spr_17_DATA
defb $FF, $0, $11, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $FF, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $11, $FF
defb $CC, $0, $11, $FF
defb $FF, $CC, $11, $FF
defb $FF, $CC, $11, $FF
defb $FF, $0, $77, $FF
defb $FF, $0, $77, $FF
._spr_18
defb $4, $10
._spr_18_DATA
defb $0, $F0, $E0, $0
defb $10, $F7, $3C, $0
defb $10, $FD, $D6, $0
defb $10, $FD, $D6, $0
defb $10, $DD, $56, $0
defb $10, $FF, $DE, $0
defb $10, $7F, $DE, $0
defb $30, $D5, $24, $0
defb $31, $F0, $F0, $80
defb $30, $F2, $4B, $80
defb $0, $F5, $C3, $80
defb $0, $F0, $F0, $80
defb $0, $E5, $80, $0
defb $0, $E1, $80, $0
defb $0, $30, $E0, $0
defb $0, $31, $2C, $0
._spr_19
defb $4, $10
._spr_19_DATA
defb $FF, $0, $11, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $FF
defb $CC, $0, $11, $FF
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $FF, $0, $0, $77
defb $FF, $0, $0, $77
defb $FF, $0, $77, $FF
defb $FF, $0, $77, $FF
defb $FF, $CC, $11, $FF
defb $FF, $CC, $11, $FF
._spr_20
defb $4, $10
._spr_20_DATA
defb $0, $0, $0, $0
defb $0, $70, $C0, $0
defb $0, $72, $C8, $0
defb $0, $90, $20, $0
defb $30, $6, $1C, $80
defb $60, $4, $4, $C0
defb $D0, $A2, $B8, $60
defb $B0, $F0, $F0, $A0
defb $B0, $B1, $B0, $A0
defb $B0, $A0, $B0, $A0
defb $D0, $B0, $B0, $60
defb $50, $72, $D8, $40
defb $60, $76, $CC, $C0
defb $20, $F0, $E0, $80
defb $30, $80, $30, $80
defb $0, $0, $0, $0
._spr_21
defb $4, $10
._spr_21_DATA
defb $FF, $FF, $FF, $FF
defb $FF, $88, $33, $FF
defb $FF, $88, $33, $FF
defb $FF, $0, $11, $FF
defb $CC, $0, $0, $77
defb $88, $0, $0, $33
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $0, $0, $0, $11
defb $88, $0, $0, $33
defb $88, $0, $0, $33
defb $CC, $0, $0, $77
defb $CC, $77, $CC, $77
defb $FF, $FF, $FF, $FF
._spr_22
defb $4, $10
._spr_22_DATA
defb $0, $70, $C0, $0
defb $0, $72, $44, $0
defb $F0, $90, $30, $F0
defb $10, $6, $1C, $10
defb $60, $4, $4, $D0
defb $70, $A2, $B8, $D0
defb $60, $F0, $E0, $D0
defb $B0, $71, $D0, $B0
defb $D0, $E0, $F0, $60
defb $60, $72, $C8, $C0
defb $30, $F2, $F8, $80
defb $0, $F6, $EC, $0
defb $0, $F0, $E0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
._spr_23
defb $4, $10
._spr_23_DATA
defb $FF, $88, $33, $FF
defb $FF, $88, $33, $FF
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $11
defb $88, $0, $0, $33
defb $CC, $0, $0, $77
defb $FF, $0, $11, $FF
defb $FF, $0, $11, $FF
defb $FF, $FF, $FF, $FF
defb $FF, $FF, $FF, $FF
defb $FF, $FF, $FF, $FF
._spr_24
defb $4, $10
._spr_24_DATA
defb $10, $C0, $0, $0
defb $10, $78, $E0, $0
defb $10, $68, $30, $0
defb $10, $78, $90, $80
defb $10, $7B, $C8, $80
defb $10, $59, $64, $80
defb $10, $7B, $AC, $80
defb $30, $6A, $F8, $80
defb $31, $BC, $D3, $80
defb $31, $CB, $B4, $80
defb $30, $E1, $68, $0
defb $0, $B4, $E0, $0
defb $0, $96, $A4, $0
defb $0, $F0, $F0, $0
defb $0, $0, $96, $0
defb $0, $0, $F0, $0
._spr_25
defb $4, $10
._spr_25_DATA
defb $EE, $33, $FF, $FF
defb $EE, $0, $11, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $11, $FF
defb $FF, $0, $11, $FF
defb $FF, $0, $11, $FF
defb $FF, $0, $0, $FF
defb $FF, $FF, $0, $FF
defb $FF, $FF, $0, $FF
._spr_26
defb $4, $10
._spr_26_DATA
defb $10, $F0, $E0, $0
defb $10, $68, $30, $0
defb $10, $78, $90, $80
defb $10, $7B, $C8, $80
defb $10, $59, $64, $80
defb $10, $7B, $EC, $80
defb $10, $6A, $BC, $80
defb $30, $78, $F0, $80
defb $31, $9E, $3D, $80
defb $31, $CB, $B4, $80
defb $30, $E1, $78, $0
defb $0, $70, $D2, $0
defb $0, $52, $96, $0
defb $0, $F0, $F0, $0
defb $0, $96, $0, $0
defb $0, $F0, $0, $0
._spr_27
defb $4, $10
._spr_27_DATA
defb $EE, $0, $11, $FF
defb $EE, $0, $0, $FF
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $EE, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $77
defb $CC, $0, $0, $FF
defb $FF, $88, $0, $FF
defb $FF, $88, $0, $FF
defb $FF, $0, $0, $FF
defb $FF, $0, $FF, $FF
defb $FF, $0, $FF, $FF
._spr_28
defb $4, $10
._spr_28_DATA
defb $33, $FF, $FF, $CC
defb $77, $C, $30, $2E
defb $67, $C1, $38, $E0
defb $56, $1, $8, $E0
defb $56, $7, $E, $E0
defb $74, $7, $E, $E0
defb $74, $1, $8, $E0
defb $74, $C1, $38, $E0
defb $34, $C1, $38, $E0
defb $12, $C1, $38, $C0
defb $12, $C0, $30, $C0
defb $12, $F0, $F0, $80
defb $12, $F0, $F0, $40
defb $12, $F0, $E0, $80
defb $12, $F0, $50, $40
defb $0, $0, $0, $0
._spr_29
defb $4, $10
._spr_29_DATA
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $0, $0, $0, $0
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $CC, $0, $0, $33
._spr_30
defb $4, $10
._spr_30_DATA
defb $11, $FF, $0, $0
defb $33, $9F, $FF, $EE
defb $33, $68, $10, $97
defb $23, $80, $1C, $E1
defb $23, $A1, $C, $70
defb $32, $83, $F, $70
defb $32, $80, $1E, $70
defb $32, $E0, $C, $70
defb $12, $D0, $58, $F0
defb $12, $C1, $38, $E0
defb $12, $C0, $38, $C0
defb $12, $F0, $30, $C0
defb $12, $F0, $F0, $80
defb $12, $F0, $F0, $40
defb $12, $F0, $E0, $80
defb $0, $0, $50, $40
._spr_31
defb $4, $10
._spr_31_DATA
defb $CC, $0, $0, $11
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $0
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $88, $0, $0, $11
defb $CC, $0, $0, $11
#endasm

