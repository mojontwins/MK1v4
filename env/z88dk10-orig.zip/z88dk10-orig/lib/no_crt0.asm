MODULE no_crt0
INCLUDE "zcc_opt.def"

XREF _main                     ;main() is always external to crt0

	org 0
.start
   jp _main

.l_dcal
   jp (hl)
   