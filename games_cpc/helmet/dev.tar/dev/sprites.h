// MTE MK1 (la Churrera) v5.0
// Copyleft 2010-2014, 2020 by the Mojon Twins

// Sprites.h
extern unsigned char sprites [0]; 
 
#asm
    ._sprites
        BINARY "sprites.bin"
#endasm
 