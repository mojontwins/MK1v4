// MTE MK1 v4.8
// Copyleft 2010-2013, 2020-2021 by The Mojon Twins

// beeper.h
// Cointains Beeper sound effects

// Most effects have been taken off BeepFX's demo project.
// So I guess they should be credited to Shiru again ;)

/*
	TABLA DE SONIDOS

	n	Sonido
	----------
	1	Salto
	2	enemy hit
	3	killzone hit
	4	countdown
	5	coin
	6	object
	7	talk 1
	8	key in lock
	9	shoot
	10	explosion
	11	talk 2	
	12  ramiro hover (only AY)
*/

void beepet (void) {

}
